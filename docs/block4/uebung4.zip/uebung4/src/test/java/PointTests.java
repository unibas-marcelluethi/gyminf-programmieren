
import edu.illinois.cs.cs125.gradlegrader.annotations.Graded;
import edu.illinois.cs.cs125.gradlegrader.annotations.Tag;
import org.junit.Test;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import static org.junit.Assert.assertEquals;

public class PointTests {


    @Test(timeout = 1000)
    @Graded(points = 1)
    @Tag(name = "difficulty", value = "simple")
    @Tag(name = "function", value = "pointRetainsCoordinates")
    public void testPointRetainsCoordinates() {
       Point p1 = new Point(3, 7);
       assertEquals(3, p1.getX(), 1e-8);
       assertEquals(7, p1.getY(), 1e-8);

       Point p2 = new Point(-3.1, 7.7);
       assertEquals(-3.1, p2.getX(), 1e-8);
       assertEquals(7.7, p2.getY(), 1e-8);

    }

}
