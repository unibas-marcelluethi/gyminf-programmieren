class Complex {

  double real;
  double imag;

  /**
   * Erstellt eine neue Komplexe Zahl mit gegebenem
   * Real- und Imaginärteil.
   */
  Complex(double real, double imag) {
    // ihr Code
  }

  /**
   * Addiert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexe Zahl. Das Ergebnis
   * wir als neue Komplexe Zahl zurückgegeben.
   */
  public Complex add(Complex other) {
     
    // ihr Code
    return null;
  }

  /* Addiert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Nach diese
   * Operation soll das aktuelle Objekt der Addition beider
   * Zahlen entsprechen.
   */
  public void addInplace(Complex other) {
     
    // ihr Code
    
  }

  /**
   * Multipliziert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Das Ergebnis wird
   * als neue Komplexe Zahl zurückgegeben.
   */
  Complex multiply(Complex other) {
     
    // ihr Code
    return null;
  }

  /**
   * Multipliziert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Nach dieser
   * Operation soll das aktuelle Objekt der Multiplikation beider
   * Zahlen entsprechen.
   */
  void multiplyInplace(Complex other) {
     
    // ihr Code
  }


  /**
   * Gibt den Absolutwert der Komplexen Zahl zurück
   */
  public double abs() {
     
    // ihr Code
    return 0;
  }



}