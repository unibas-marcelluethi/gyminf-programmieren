import ch.unibas.informatik.jturtle.Turtle;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class Rectangle {

  // Definieren Sie hier alle Felder die Sie benötigen.

  /**
   * Kreiert ein neues Rectangle Objekt, welches ein Rechteck durch den unteren
   * Linken Punkt, sowie dessen Breite und Höhe definiert.
   */
  Rectangle(Point lowerLeftCorner, double width, double height) {
    // Ihre Implementation
  }

  /**
   * Diese Methode nutzt das als Argument übergebene Turtle um das Rechteck an der
   * vorgegebenen Position zu zeichnen. Nutzen Sie die statische Methode
   * TurtleUtils.setTurtlePosition um das Turtle an die richtige Position zu
   * setzen.
   */
  void drawWithTurtle(Turtle turtle) {
    // Ihre Implementation
  }

    /**
     * Einfaches Testprogramm um Ihre Zeichnung zu testen
     */
    public static void main(String[] args) {

      Rectangle rect = new Rectangle(new Point(-30, -50), 60, 100);
      Turtle turtle = new Turtle();
      rect.drawWithTurtle(turtle);

      BufferedImage img = turtle.toImage();

      try {
        ImageIO.write(img, "png", new java.io.File("rectangle.png"));
      } catch (IOException e) {
        System.err.println(e.getMessage());
      }
  }
}
