import ch.unibas.informatik.jturtle.Turtle;


class TurtleUtils {

    /**
     * Setzt die Position vom Turtle an die durch den Punkt gegebene Position.
     */
    static void setTurtlePosition(Turtle turtle, Point point) {
      turtle.home();
      turtle.penUp();
  
      turtle.forward(point.getY());
      turtle.turnRight(90);
      turtle.forward(point.getX());
      turtle.turnLeft(90);
  
  
    }
  }