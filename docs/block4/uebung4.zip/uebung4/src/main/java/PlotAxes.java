import ch.unibas.informatik.jturtle.Turtle;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class PlotAxes {

  // Definieren Sie hier alle Felder die Sie benötigen.

  /**
   * Kreiert ein Objekt der Klasse PlotAxes, welches durch den Koordinatenursprung
   * (also den Punkt unten Links) sowie die Längen der x und y-Achse definiert
   * ist.
   */
  PlotAxes(Point origin, double lengthXAxis, double lengthYAxis) {
    // Ihre Implementation
  }

  /**
   * Diese Methode nutzt das als Argument übergebene Turtle um die
   * Koordinatenachsen an der vorgegebenen Position zu zeichnen. Nutzen Sie die
   * statische Methode TurtleUtils.setTurtlePosition um das Turtle an die richtige
   * Position zu setzen.
   */
  void drawWithTurtle(Turtle turtle) {
    // Ihre Implementation
  }

  /**
   * Einfaches Testprogramm um Ihre Zeichnung zu testen
   */
  public static void main(String[] args) {

    Turtle turtle = new Turtle();
    PlotAxes pa = new PlotAxes(new Point(-30, -50), 60, 100);
    pa.drawWithTurtle(turtle);

    BufferedImage img = turtle.toImage();

    try {
      ImageIO.write(img, "png", new java.io.File("axes.png"));
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

}