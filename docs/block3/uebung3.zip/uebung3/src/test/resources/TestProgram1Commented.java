
class TestProgram { 

    /*
    public void aMethodThatIsCommentedOut {

    }
    */

    // This is the main method
    public static void main(String[] args) {
        
        // It prints out something
        System.out.println("hello world");

        /**
         * And has nested comments in it 
         * //
         */

         // And more nested comments /* */

         System.out.println("another statement");

         // Furthermore, entire codeblocks are commented out

         /*
         System.out.println("line 1");
         System.out.println("line 2");
         System.out.println("line 3");
        */

    }
}
