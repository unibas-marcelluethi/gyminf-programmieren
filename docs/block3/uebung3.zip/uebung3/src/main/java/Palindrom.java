
import java.io.IOException;

public class Palindrom  {

  /**
   * Gibt true zurück falls der übergeben String ein Palindrom ist.
   */
  public static boolean testPalindrom(String s) {
    // Implementieren Sie diese Methode
    return true;
  }

  

  public static void main(String[] args) throws IOException {
    // Hier kommt ihr eigener Testcode hin
  }
}