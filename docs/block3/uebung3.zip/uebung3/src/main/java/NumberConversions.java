

public class NumberConversions {



    /**
     * Diese Methode wandelt eine als String übergebene Binärzahl in 
     * eine Dezimalzahl um und gibt diese zuück.
     * Das Argument hat die Form 0b{0|1}, (also z.B. 0b11110) wobei 
     * das 0b anzeigt, dass es sich hier um einen Binärzahl handelt. 
     */
    public static int binToDec(String numberString) {
 
        // Implementieren Sie diese Methode
        return 0;
    }

    /*
     * Diese Methode wandelt eine gegebene (positive) Dezimalzahl in einen 
     * String um, der die Hexadezimale Form der Zahl ausgibt.
     */
    public static String decToHex(int dec) {
        
        // Implementieren Sie diese Methode
        return "";

    }



    public static void main(String[] args) {
        
        if (args.length < 1) {
            System.out.println("Bitte beim Aufruf eine Zahl übergeben");
        }

        String numberString = args[0];
        if (numberString.trim().startsWith("0b")) {
            System.out.println(binToDec(numberString));
        } else {
            System.out.println(decToHex(Integer.parseInt(numberString)));
        }

    }
}