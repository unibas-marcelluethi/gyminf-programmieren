class Matrix {

  /**
   * Gibt die Transponierte der Übergebenen Matrix zurück. 
   * Die Übergebene Matrix darf nicht verändert werden. 
   */
  static double[][] transpose(double[][] matrix) {

    // Ihr Code kommt hierhin
  
    return null; // Geben Sie hier statt null Ihre Matrix zurück

  }

  /*
  * Hilfsfunktion um eine Matrix auszugeben. 
  */
  static void displayMatrix(double[][] matrix) {
    for (int i = 0; i < matrix.length; i++) {
      System.out.print("[ "); // EDIT: changed println to print
      for (int j = 0; j < matrix[0].length; j++) { 
        System.out.print(matrix[i][j] + " ");
      }
      System.out.println("]");
    }
  }


  public static void main(String[] args) { 

      // Schreiben Sie hier ihren eigenen Code um das Programm zu testen
    
  }  


}