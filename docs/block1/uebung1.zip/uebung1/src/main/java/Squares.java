

import ch.unibas.informatik.jturtle.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Squares {
  public static void main(String[] args) throws IOException {

    System.out.println(args.length);
    System.out.println(args[0]);
    if (args.length < 1) {
      System.out.println("Usage Squares imageFilename");
      System.exit(-1);
    }

    String outputImageFileName = args[0];



    Turtle t = new Turtle();
   
    // Schreiben Sie hier Ihre Turtle Befehle hin

    
    BufferedImage image = t.toImage();
    ImageIO.write(image, "png", new File(outputImageFileName));
  }
}

