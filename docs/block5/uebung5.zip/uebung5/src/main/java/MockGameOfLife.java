public class MockGameOfLife extends GameOfLife {

  private int theSize = 5;
  private int t = 0;

  public MockGameOfLife() {
    super(new boolean[5][5]);
  }

  public int getSize() {
    return theSize;
  }

  public boolean isActive(int i, int j) {
    if (t % 2 == 0) {
      return (j == 2  && (i == 1 || i == 2 || i == 3));
    } else {
      return (i == 2  && (j == 1 || j == 2 || j == 3));
    }
  }

  public int getNumberOfActiveNeighbors(int i, int j) {
    return 0;
  }

  public void update() {
    t += 1;
  }

  public String toString() {
    return "";
  }
}
