import java.util.Random;

/**
 * Dieses Objekt simuliert ein GameOfLife mit einer fixen Konfiguration
 */
public class GameOfLife {

  // Ihre Felder

  /**
   * Kreiert eine neue Instanz vom Game Of Life. Dabei wird die 
   * Startkonfiguration im array cells übergeben.
   */
  public GameOfLife(boolean[][] cells) {
    // Ihre Implementation
  }

  /**
   * Gibt die Grösse der Welt zurück. 
   * Beispiel für eine Welt der Grösse 5 x 5  wird 5 zurückgegeben.
   * @return
   */
  public int getSize() {
    // Ihre Implementation
    return 0;
  }

  /**
   * Gibt true zurück, falls die Zelle an der Stelle i,j
   * aktiv ist. 
   */
  public boolean isActive(int i, int j) {
    // Ihre Implementation
    return true;
  }

  /**
   * Gibt die Anzahl aktiver Nachbarn zurück.   
   */
  public int getNumberOfActiveNeighbors(int i, int j) {
      // Ihre Implementation
      return 0;
  }

  /**
   * Führt einen Updateschritt gemäss  
   * den Regeln vom Game Of Life aus (siehe Übungsblatt).
   */
  public void update() {
      // Ihre Implementation      
  }


  /**
   * Gibt die Konfiguration als formtierten String zurück
   * (Details siehe Übungsblatt)
   */
  public String toString() {
    
    // Ihre Implementation
    return "";
  }

  /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * block.
   */
  public static GameOfLife createBlock() {
      // Ihre Implementation
      return null;
  }

 /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * blinker.
   */
  public static GameOfLife createBlinker() {
      // Ihre Implementation
      return null;

  }

   /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * Glider.
   */
  public static GameOfLife createGlider() {
      // Ihre Implementation
      return null;
  }

  /**
   * Kreiert ein neues Game Of Life Objekt der Grösse size.
   * Dabei ist jede Zelle mit der angegebenen Wahrscheinlichkeit aktiv.
   */
  public static GameOfLife createRandom(int size, double probability) {
    assert(probability >= 0 && probability <= 1);

    // Ihre Implementation
      return null;

  }



}
